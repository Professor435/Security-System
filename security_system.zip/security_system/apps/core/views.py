from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from django.contrib.auth import logout
# Import your models
from apps.incidents.models import Incident
from apps.vulnerabilities.models import Vulnerability
from apps.policies.models import SecurityPolicy
from apps.audit.models import AuditLog


@login_required
def dashboard(request):
    """Main dashboard view"""
    context = {
        'incident_count': Incident.objects.filter(status='open').count(),
        'vulnerability_count': Vulnerability.objects.filter(status='open').count(),
        'policy_count': SecurityPolicy.objects.filter(status='active').count(),
    }
    return render(request, 'core/dashboard.html', context)


@login_required
def incidents(request):
    """List all incidents"""
    incident_list = Incident.objects.all().order_by('-created_at')
    
    context = {
        'incidents': incident_list,
    }
    return render(request, 'core/incident_list.html', context)


@login_required
def incident_create(request):
    """Create new incident"""
    if request.method == 'POST':
        try:
            incident = Incident.objects.create(
                title=request.POST.get('title'),
                category=request.POST.get('category'),
                severity=request.POST.get('severity'),
                description=request.POST.get('description'),
                reporter=request.user
            )
            messages.success(request, 'Incident created successfully!')
            return redirect('incident_list')
        except Exception as e:
            messages.error(request, f'Error creating incident: {str(e)}')
            return redirect('incident_list')
    
    return redirect('incident_list')


@login_required
def vulnerabilities(request):
    """List all vulnerabilities"""
    vulnerability_list = Vulnerability.objects.all().order_by('-created_at')
    critical_count = Vulnerability.objects.filter(severity='critical').count()
    high_count = Vulnerability.objects.filter(severity='high').count()
    medium_count = Vulnerability.objects.filter(severity='medium').count()
    low_count = Vulnerability.objects.filter(severity='low').count()
    
    context = {
        'vulnerabilities': vulnerability_list,
        'critical_count': critical_count,
        'high_count': high_count,
        'medium_count': medium_count,
        'low_count': low_count,
    }
    return render(request, 'core/vulnerability_list.html', context)


@login_required
def vulnerability_create(request):
    """Create new vulnerability"""
    if request.method == 'POST':
        try:
            vuln = Vulnerability.objects.create(
                title=request.POST.get('title'),
                severity=request.POST.get('severity'),
                description=request.POST.get('description'),
            )
            messages.success(request, 'Vulnerability created successfully!')
            return redirect('vulnerability_list')
        except Exception as e:
            messages.error(request, f'Error creating vulnerability: {str(e)}')
            return redirect('vulnerability_list')
    
    return redirect('vulnerability_list')


@login_required
def policies(request):
    """List all policies"""
    policy_list = SecurityPolicy.objects.all().order_by('-updated_at')
    
    context = {
        'policies': policy_list,
    }
    return render(request, 'core/policy_list.html', context)


@login_required
def policy_create(request):
    """Create new policy"""
    if request.method == 'POST':
        try:
            policy = SecurityPolicy.objects.create(
                title=request.POST.get('title'),
                policy_type=request.POST.get('policy_type'),
                content=request.POST.get('content', ''),
                status='draft',
            )
            messages.success(request, 'Policy created successfully!')
            return redirect('policy_list')
        except Exception as e:
            messages.error(request, f'Error creating policy: {str(e)}')
            return redirect('policy_list')
    
    return redirect('policy_list')


@login_required
def audit(request):
    """Audit logs view"""
    audit_logs = AuditLog.objects.all().order_by('-timestamp')[:100]
    
    context = {
        'audit_logs': audit_logs,
    }
    return render(request, 'core/audit.html', context)


def custom_logout(request):
    logout(request)
    return redirect('/login/')