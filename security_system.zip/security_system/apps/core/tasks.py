
"""
Celery tasks for background security operations
"""

from celery import shared_task
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from django.db.models import Avg
from datetime import timedelta
import logging

from apps.incidents.models import Incident
from apps.vulnerabilities.models import Vulnerability, RemediationSLA
from apps.accounts.models import User, SecurityAlert
from apps.audit.models import AuditLog

logger = logging.getLogger('security')


@shared_task
def check_sla_violations():
    """Check for SLA violations on open vulnerabilities"""
    open_vulns = Vulnerability.objects.filter(
        status__in=['open', 'confirmed', 'in_progress'],
        remediation_deadline__isnull=False,
        remediation_deadline__lt=timezone.now()
    )
    
    count = 0
    for vuln in open_vulns:
        if not vuln.is_overdue():
            continue
            
        # Log SLA violation
        AuditLog.objects.create(
            event_type=AuditLog.EventType.POLICY_VIOLATION,
            severity=AuditLog.Severity.HIGH,
            resource_type='Vulnerability',
            resource_id=str(vuln.id),
            description=f"SLA violation for vulnerability {vuln.vuln_id}",
            metadata={'days_overdue': vuln.days_open() - vuln.remediation_deadline.days}
        )
        
        # Notify assignee
        if vuln.assigned_to:
            SecurityAlert.objects.create(
                user=vuln.assigned_to,
                alert_type=SecurityAlert.AlertType.POLICY_VIOLATION,
                title=f"SLA Violation: {vuln.vuln_id}",
                message=f"Vulnerability {vuln.title} has exceeded remediation SLA",
                severity='high'
            )
        
        count += 1
    
    logger.info(f"SLA check complete. {count} violations found.")
    return f"Checked {open_vulns.count()} vulnerabilities, {count} SLA violations"


@shared_task
def send_security_digest():
    """Send daily security digest email to admins"""
    today = timezone.now()
    yesterday = today - timedelta(days=1)
    
    # Gather statistics
    new_incidents = Incident.objects.filter(created_at__gte=yesterday).count()
    resolved_incidents = Incident.objects.filter(resolved_at__gte=yesterday).count()
    new_vulns = Vulnerability.objects.filter(created_at__gte=yesterday).count()
    critical_open = Incident.objects.filter(severity='critical', status='open').count()
    
    # Get admin users
    admins = User.objects.filter(role__name__in=['super_admin', 'security_admin'])
    
    subject = f"Security Digest - {today.strftime('%Y-%m-%d')}"
    message = f"""
    Daily Security Summary:
    
    New Incidents: {new_incidents}
    Resolved Incidents: {resolved_incidents}
    New Vulnerabilities: {new_vulns}
    Critical Open Incidents: {critical_open}
    
    Dashboard: {settings.ALLOWED_HOSTS[0]}/dashboard/
    """
    
    for admin in admins:
        if admin.email:
            send_mail(
                subject=subject,
                message=message,
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=[admin.email],
                fail_silently=True
            )
    
    return f"Digest sent to {admins.count()} administrators"


@shared_task
def cleanup_old_audit_logs():
    """Archive or delete old audit logs"""
    retention_days = 365
    cutoff_date = timezone.now() - timedelta(days=retention_days)
    
    old_logs = AuditLog.objects.filter(timestamp__lt=cutoff_date)
    count = old_logs.count()
    
    # In production, you might want to archive these instead of deleting
    old_logs.delete()
    
    logger.info(f"Cleaned up {count} audit logs older than {retention_days} days")
    return f"Deleted {count} old audit logs"


@shared_task
def check_password_expiry():
    """Notify users of upcoming password expiry"""
    expiry_days = settings.SECURITY_SETTINGS.get('PASSWORD_EXPIRY_DAYS', 90)
    warning_days = 7
    
    expiry_threshold = timezone.now() - timedelta(days=expiry_days - warning_days)
    critical_threshold = timezone.now() - timedelta(days=expiry_days)
    
    # Users approaching expiry
    approaching_users = User.objects.filter(
        last_password_change__lt=expiry_threshold,
        last_password_change__gt=critical_threshold,
        is_active=True
    )
    
    for user in approaching_users:
        days_left = (user.last_password_change + timedelta(days=expiry_days) - timezone.now()).days
        SecurityAlert.objects.create(
            user=user,
            alert_type=SecurityAlert.AlertType.PASSWORD_EXPIRY,
            title="Password Expiring Soon",
            message=f"Your password will expire in {days_left} days. Please change it soon.",
            severity='medium'
        )
    
    # Force password change for expired passwords
    expired_users = User.objects.filter(
        last_password_change__lt=critical_threshold,
        is_active=True
    )
    
    for user in expired_users:
        # You might want to force a password reset here
        SecurityAlert.objects.create(
            user=user,
            alert_type=SecurityAlert.AlertType.PASSWORD_EXPIRY,
            title="Password Expired",
            message="Your password has expired. Please change it immediately.",
            severity='high'
        )
    
    return f"Notified {approaching_users.count()} users of upcoming expiry, {expired_users.count()} expired"


@shared_task
def generate_monthly_report():
    """Generate monthly security report"""
    last_month = timezone.now() - timedelta(days=30)
    
    stats = {
        'incidents_created': Incident.objects.filter(created_at__gte=last_month).count(),
        'incidents_resolved': Incident.objects.filter(resolved_at__gte=last_month).count(),
        'vulns_discovered': Vulnerability.objects.filter(created_at__gte=last_month).count(),
        'vulns_remediated': Vulnerability.objects.filter(remediated_at__gte=last_month).count(),
        'avg_resolution_time': Incident.objects.filter(
            resolved_at__gte=last_month
        ).aggregate(avg_time=Avg('time_to_resolve'))['avg_time'],
    }
    
    # Save report or send via email
    logger.info(f"Monthly report generated: {stats}")
    return stats


@shared_task(bind=True)
def run_vulnerability_scan(self, scan_id):
    """Execute vulnerability scan"""
    from apps.vulnerabilities.models import Scan
    
    try:
        scan = Scan.objects.get(id=scan_id)
        scan.status = Scan.ScanStatus.RUNNING
        scan.started_at = timezone.now()
        scan.save()
        
        # Simulate scan execution
        import time
        time.sleep(10)  # Replace with actual scanning logic
        
        # Update with results
        scan.status = Scan.ScanStatus.COMPLETED
        scan.completed_at = timezone.now()
        scan.duration = scan.completed_at - scan.started_at
        scan.total_vulnerabilities = 15  # Replace with actual count
        scan.critical_count = 2
        scan.high_count = 5
        scan.save()
        
        # Create vulnerabilities from findings
        # ...
        
        return f"Scan {scan_id} completed successfully"
        
    except Exception as exc:
        scan.status = Scan.ScanStatus.FAILED
        scan.save()
        raise self.retry(exc=exc, countdown=60, max_retries=3)
