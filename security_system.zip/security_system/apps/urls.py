
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from apps.core import views as core_views
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('apps.accounts.urls')),
    path('incidents/', include('apps.incidents.urls')),
    path('vulnerabilities/', include('apps.vulnerabilities.urls')),
    path('policies/', include('apps.policies.urls')),
    path('reports/', include('apps.reports.urls')),
    path('dashboard/', include('apps.dashboard.urls')),
    path('api/', include('apps.api.urls')),
    path('notifications/', include('apps.notifications.urls')),
    path('settings/', include('apps.settings.urls')),
    path('help/', include('apps.help.urls')),
    path('audit/', include('apps.audit.urls')),
    path('integrations/', include('apps.integrations.urls')),
    path('assets/', include('apps.assets.urls')),
    path('compliance/', include('apps.compliance.urls')),
    path('training/', include('apps.training.urls')),
    path('threat-intelligence/', include('apps.threat_intelligence.urls')),
    path('forensics/', include('apps.forensics.urls')),
    path('response/', include('apps.response.urls')),
    path('recovery/', include('apps.recovery.urls')),
    path('collaboration/', include('apps.collaboration.urls')),
    path('analytics/', include('apps.analytics.urls')),
    path('automation/', include('apps.automation.urls')),
    path('orchestration/', include('apps.orchestration.urls')),
    

    # Authentication
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    # Dashboard
    path('', core_views.dashboard, name='dashboard'),

    path('', core_views.dashboard, name='dashboard'),
    path('incidents/', core_views.incidents, name='incidents'),
    path('vulnerabilities/', core_views.vulnerabilities, name='vulnerabilities'),
    path('policies/', core_views.policies, name='policies'),
    path('audit/', core_views.audit, name='audit'),



    # JWT Auth
    path('api/auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # App APIs
    path('api/accounts/', include('apps.accounts.urls')),
    path('api/incidents/', include('apps.incidents.urls')),
    path('api/vulnerabilities/', include('apps.vulnerabilities.urls')),
    path('api/policies/', include('apps.policies.urls')),
]
