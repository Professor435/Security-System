
"""
Comprehensive Audit Logging Middleware
"""

import json
import time
from django.utils.deprecation import MiddlewareMixin
from django.utils import timezone
from .models import AuditLog


class AuditLogMiddleware(MiddlewareMixin):
    """Middleware to automatically log all requests"""
    
    def process_request(self, request):
        request.start_time = time.time()
        return None
    
    def process_response(self, request, response):
        # Skip certain paths
        if self.should_skip(request):
            return response
        
        # Only log authenticated requests or failed auth attempts
        if not request.user.is_authenticated and response.status_code != 403:
            return response
        
        # Determine event type
        event_type = self.get_event_type(request, response)
        if not event_type:
            return response
        
        # Calculate duration
        duration = None
        if hasattr(request, 'start_time'):
            duration = time.time() - request.start_time
        
        # Build log entry
        log_data = {
            'event_type': event_type,
            'severity': self.get_severity(response),
            'user': request.user if request.user.is_authenticated else None,
            'user_email': request.user.email if request.user.is_authenticated else None,
            'ip_address': self.get_client_ip(request),
            'user_agent': request.META.get('HTTP_USER_AGENT', '')[:512],
            'session_id': request.session.session_key if hasattr(request, 'session') else '',
            'resource_type': self.get_resource_type(request),
            'resource_id': self.get_resource_id(request),
            'action': request.method,
            'description': self.get_description(request, response),
            'metadata': {
                'path': request.path,
                'method': request.method,
                'status_code': response.status_code,
                'duration_ms': round(duration * 1000, 2) if duration else None,
                'query_params': dict(request.GET),
            }
        }
        
        # Add request/response data for changes
        if request.method in ['POST', 'PUT', 'PATCH']:
            try:
                body = json.loads(request.body) if request.body else {}
                log_data['new_state'] = self.sanitize_sensitive_data(body)
            except:
                pass
        
        try:
            AuditLog.objects.create(**log_data)
        except Exception as e:
            # Log to console if database logging fails
            import logging
            logger = logging.getLogger('security')
            logger.error(f"Failed to create audit log: {e}")
        
        return response
    
    def should_skip(self, request):
        """Skip logging for certain paths"""
        skip_paths = ['/static/', '/media/', '/health/', '/favicon.ico']
        return any(request.path.startswith(path) for path in skip_paths)
    
    def get_event_type(self, request, response):
        """Determine event type from request"""
        path = request.path.lower()
        method = request.method
        
        if 'login' in path:
            if response.status_code == 200:
                return AuditLog.EventType.LOGIN
            else:
                return AuditLog.EventType.LOGIN_FAILED
        
        if 'logout' in path:
            return AuditLog.EventType.LOGOUT
        
        if 'password' in path:
            return AuditLog.EventType.PASSWORD_CHANGE
        
        if 'incident' in path:
            if method == 'POST':
                return AuditLog.EventType.INCIDENT_CREATED
            elif method in ['PUT', 'PATCH']:
                return AuditLog.EventType.INCIDENT_UPDATED
        
        if 'vulnerability' in path:
            if method == 'POST':
                return AuditLog.EventType.VULNERABILITY_DISCOVERED
        
        if response.status_code == 403:
            return AuditLog.EventType.PERMISSION_DENIED
        
        if method == 'GET':
            return AuditLog.EventType.DATA_VIEWED
        elif method == 'POST':
            return AuditLog.EventType.DATA_CREATED
        elif method in ['PUT', 'PATCH']:
            return AuditLog.EventType.DATA_MODIFIED
        elif method == 'DELETE':
            return AuditLog.EventType.DATA_DELETED
        
        return None
    
    def get_severity(self, response):
        """Determine severity based on response"""
        if response.status_code >= 500:
            return AuditLog.Severity.CRITICAL
        elif response.status_code == 403:
            return AuditLog.Severity.HIGH
        elif response.status_code >= 400:
            return AuditLog.Severity.MEDIUM
        return AuditLog.Severity.INFO
    
    def get_client_ip(self, request):
        """Extract client IP"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR')
    
    def get_resource_type(self, request):
        """Extract resource type from URL"""
        parts = request.path.strip('/').split('/')
        if len(parts) >= 2:
            return parts[1]  # e.g., 'api/incidents/' -> 'incidents'
        return 'unknown'
    
    def get_resource_id(self, request):
        """Extract resource ID from URL"""
        parts = request.path.strip('/').split('/')
        for part in parts:
            if len(part) == 36:  # UUID length
                return part
        return ''
    
    def get_description(self, request, response):
        """Generate human-readable description"""
        return f"{request.method} {request.path} - {response.status_code}"
    
    def sanitize_sensitive_data(self, data):
        """Remove sensitive fields from logged data"""
        sensitive_fields = ['password', 'token', 'secret', 'credit_card', 'ssn']
        if isinstance(data, dict):
            return {
                k: '[REDACTED]' if any(s in k.lower() for s in sensitive_fields) else v
                for k, v in data.items()
            }
        return data
