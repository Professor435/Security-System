from django.db import models
import uuid


class AuditLog(models.Model):
    """Comprehensive Audit Logging Model"""
    
    class EventType(models.TextChoices):
        # User & Authentication Events
        LOGIN = 'login', 'Login'
        LOGOUT = 'logout', 'Logout'
        LOGIN_FAILED = 'login_failed', 'Login Failed'
        PASSWORD_CHANGE = 'password_change', 'Password Change'
        PASSWORD_RESET = 'password_reset', 'Password Reset'
        ACCOUNT_LOCKED = 'account_locked', 'Account Locked'
        ACCOUNT_UNLOCKED = 'account_unlocked', 'Account Unlocked'
        
        # Data Events (CRUD)
        DATA_VIEWED = 'data_viewed', 'Data Viewed'
        DATA_CREATED = 'data_created', 'Data Created'
        DATA_MODIFIED = 'data_modified', 'Data Modified'
        DATA_DELETED = 'data_deleted', 'Data Deleted'
        
        # Incident Events
        INCIDENT_CREATED = 'incident_created', 'Incident Created'
        INCIDENT_UPDATED = 'incident_updated', 'Incident Updated'
        
        # Vulnerability Events
        VULNERABILITY_DISCOVERED = 'vulnerability_discovered', 'Vulnerability Discovered'
        
        # Security Events
        PERMISSION_DENIED = 'permission_denied', 'Permission Denied'
        SUSPICIOUS_ACTIVITY = 'suspicious_activity', 'Suspicious Activity'
        MFA_ENABLED = 'mfa_enabled', 'MFA Enabled'
        MFA_DISABLED = 'mfa_disabled', 'MFA Disabled'
        MFA_FAILED = 'mfa_failed', 'MFA Failed'
        
        # System Events
        SETTINGS_CHANGED = 'settings_changed', 'Settings Changed'
        BACKUP_CREATED = 'backup_created', 'Backup Created'
        EXPORT_CREATED = 'export_created', 'Export Created'

    class Severity(models.TextChoices):
        INFO = 'info', 'Info'
        LOW = 'low', 'Low'
        MEDIUM = 'medium', 'Medium'
        HIGH = 'high', 'High'
        CRITICAL = 'critical', 'Critical'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    # Event Information
    event_type = models.CharField(max_length=50, choices=EventType.choices)
    severity = models.CharField(max_length=20, choices=Severity.choices, default=Severity.INFO)
    
    # User Information
    user = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True, blank=True)
    user_email = models.EmailField(blank=True)
    
    # Request Information
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    session_id = models.CharField(max_length=255, blank=True)
    
    # Resource Information
    resource_type = models.CharField(max_length=100, blank=True)
    resource_id = models.CharField(max_length=100, blank=True)
    action = models.CharField(max_length=20, blank=True)
    
    # Content
    description = models.TextField(blank=True)
    new_state = models.JSONField(null=True, blank=True)
    metadata = models.JSONField(null=True, blank=True)
    
    # Status
    status = models.CharField(max_length=20, default='success')
    
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']
        verbose_name = 'Audit Log'
        verbose_name_plural = 'Audit Logs'
        indexes = [
            models.Index(fields=['timestamp']),
            models.Index(fields=['user']),
            models.Index(fields=['event_type']),
            models.Index(fields=['severity']),
        ]

    def __str__(self):
        return f"{self.event_type} - {self.user_email} - {self.timestamp}"