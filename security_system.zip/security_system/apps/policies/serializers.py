
from rest_framework import serializers
from .models import SecurityPolicy, Control, RiskAssessment


class SecurityPolicySerializer(serializers.ModelSerializer):
    class Meta:
        model = SecurityPolicy
        fields = '__all__'
        read_only_fields = ['policy_number']


class ControlSerializer(serializers.ModelSerializer):
    class Meta:
        model = Control
        fields = '__all__'


class RiskAssessmentSerializer(serializers.ModelSerializer):
    risk_score = serializers.IntegerField(read_only=True)
    risk_level = serializers.CharField(read_only=True)
    
    class Meta:
        model = RiskAssessment
        fields = '__all__'
        read_only_fields = ['assessment_id']
