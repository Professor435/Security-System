"""
Security Policies Models
"""

import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone


class SecurityPolicy(models.Model):
    """Security Policies"""
    
    class PolicyType(models.TextChoices):
        ACCEPTABLE_USE = 'acceptable_use', 'Acceptable Use Policy'
        ACCESS_CONTROL = 'access_control', 'Access Control Policy'
        INCIDENT_RESPONSE = 'incident_response', 'Incident Response Plan'
        DATA_PROTECTION = 'data_protection', 'Data Protection Policy'
    
    class Status(models.TextChoices):
        DRAFT = 'draft', 'Draft'
        ACTIVE = 'active', 'Active'
        RETIRED = 'retired', 'Retired'
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=255)
    policy_type = models.CharField(max_length=50, choices=PolicyType.choices)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-updated_at']
    
    def __str__(self):
        return self.title


class Control(models.Model):
    """Security Controls"""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    control_id = models.CharField(max_length=50, unique=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    implementation_status = models.CharField(max_length=20, choices=[
        ('not_implemented', 'Not Implemented'),
        ('partially', 'Partially Implemented'),
        ('implemented', 'Implemented'),
        ('exceeds', 'Exceeds Requirements'),
    ], default='not_implemented')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.control_id}: {self.title}"


class RiskAssessment(models.Model):
    """Security Risk Assessments"""
    class RiskLevel(models.TextChoices):
        CRITICAL = 'critical', 'Critical'
        HIGH = 'high', 'High'
        MEDIUM = 'medium', 'Medium'
        LOW = 'low', 'Low'
        NEGLIGIBLE = 'negligible', 'Negligible'
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    assessment_id = models.CharField(max_length=20, unique=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    likelihood = models.PositiveSmallIntegerField()
    impact = models.PositiveSmallIntegerField()
    risk_score = models.PositiveSmallIntegerField()
    risk_level = models.CharField(max_length=20, choices=RiskLevel.choices)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-risk_score']
    
    def __str__(self):
        return f"{self.assessment_id}: {self.title}"