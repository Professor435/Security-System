
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import SecurityPolicy, Control, RiskAssessment
from .serializers import (
    SecurityPolicySerializer, ControlSerializer, RiskAssessmentSerializer
)


class SecurityPolicyViewSet(viewsets.ModelViewSet):
    queryset = SecurityPolicy.objects.all()
    serializer_class = SecurityPolicySerializer
    permission_classes = [IsAuthenticated]


class ControlViewSet(viewsets.ModelViewSet):
    queryset = Control.objects.all()
    serializer_class = ControlSerializer
    permission_classes = [IsAuthenticated]


class RiskAssessmentViewSet(viewsets.ModelViewSet):
    queryset = RiskAssessment.objects.all()
    serializer_class = RiskAssessmentSerializer
    permission_classes = [IsAuthenticated]
