from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Role, SecurityAlert, UserSession

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ['email', 'username', 'first_name', 'last_name', 'role', 'is_active', 'mfa_enabled']
    list_filter = ['is_active', 'role', 'mfa_enabled', 'date_joined']
    search_fields = ['email', 'username', 'first_name', 'last_name']
    ordering = ['-date_joined']
    
    fieldsets = (
        (None, {'fields': ('email', 'username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'phone_number')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'role', 'groups', 'user_permissions')}),
        ('Security', {'fields': ('mfa_enabled', 'last_login_ip', 'failed_login_attempts', 'locked_until')}),
        ('Important dates', {'fields': ('last_login', 'date_joined', 'last_password_change')}),
    )

@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'is_active', 'created_at']
    filter_horizontal = ['permissions']

@admin.register(SecurityAlert)
class SecurityAlertAdmin(admin.ModelAdmin):
    list_display = ['title', 'user', 'alert_type', 'severity', 'is_read', 'created_at']
    list_filter = ['severity', 'alert_type', 'is_read']

@admin.register(UserSession)
class UserSessionAdmin(admin.ModelAdmin):
    list_display = ['user', 'ip_address', 'is_active', 'created_at', 'last_activity']
    list_filter = ['is_active']

