
"""
Custom Authentication and Security Middleware
"""

import pyotp
import qrcode
import io
import base64
from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.conf import settings
from rest_framework import authentication, exceptions
from rest_framework_simplejwt.authentication import JWTAuthentication

User = get_user_model()


class MFAAwareJWTAuthentication(JWTAuthentication):
    """JWT Authentication that respects MFA requirements"""
    
    def authenticate(self, request):
        header = self.get_header(request)
        if header is None:
            return None
        
        raw_token = self.get_raw_token(header)
        if raw_token is None:
            return None
        
        validated_token = self.get_validated_token(raw_token)
        user = self.get_user(validated_token)
        
        # Check if MFA is required but not verified
        if self.mfa_required(user) and not self.mfa_verified(request, user):
            raise exceptions.AuthenticationFailed('MFA verification required')
        
        return user, validated_token
    
    def mfa_required(self, user):
        """Check if MFA is required for this user"""
        if user.role and user.role.name in ['super_admin', 'security_admin']:
            return settings.SECURITY_SETTINGS.get('REQUIRE_MFA_FOR_ADMIN', True)
        return user.mfa_enabled
    
    def mfa_verified(self, request, user):
        """Check if MFA has been verified in this session"""
        session_key = f'mfa_verified_{user.id}'
        return request.session.get(session_key, False) or not self.mfa_required(user)


class RateLimitAuthentication(authentication.BaseAuthentication):
    """Rate limiting for authentication attempts"""
    
    def authenticate(self, request):
        ip = self.get_client_ip(request)
        key = f'auth_attempts_{ip}'
        attempts = cache.get(key, 0)
        
        if attempts >= 5:
            raise exceptions.Throttled(detail='Too many authentication attempts. Please try again later.')
        
        return None
    
    def get_client_ip(self, request):
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0]
        return request.META.get('REMOTE_ADDR')


class MFAService:
    """Multi-Factor Authentication Service"""
    
    @staticmethod
    def generate_secret():
        """Generate new MFA secret"""
        return pyotp.random_base32()
    
    @staticmethod
    def get_totp_uri(secret, user):
        """Get TOTP URI for QR code generation"""
        return pyotp.totp.TOTP(secret).provisioning_uri(
            name=user.email,
            issuer_name=settings.SECURITY_SETTINGS.get('MFA_ISSUER_NAME', 'Security Management System')
        )
    
    @staticmethod
    def generate_qr_code(uri):
        """Generate QR code as base64 image"""
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        return base64.b64encode(buffer.getvalue()).decode()
    
    @staticmethod
    def verify_token(secret, token):
        """Verify TOTP token"""
        totp = pyotp.TOTP(secret)
        return totp.verify(token, valid_window=1)
    
    @staticmethod
    def generate_backup_codes():
        """Generate single-use backup codes"""
        import secrets
        return [secrets.token_hex(4) for _ in range(10)]


class AccountLockoutMiddleware:
    """Middleware to handle account lockouts"""
    
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        if request.user.is_authenticated and request.user.is_locked():
            from django.contrib.auth import logout
            logout(request)
            from django.http import JsonResponse
            return JsonResponse({
                'error': 'Account locked',
                'message': f'Account locked until {request.user.locked_until}'
            }, status=403)
        
        response = self.get_response(request)
        return response
