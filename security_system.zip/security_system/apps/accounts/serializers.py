
from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Role, SecurityAlert, UserSession

User = get_user_model()


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['id', 'name', 'description', 'is_active']


class UserBriefSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'username', 'first_name', 'last_name']


class UserSerializer(serializers.ModelSerializer):
    role_name = serializers.CharField(source='role.name', read_only=True)
    full_name = serializers.CharField(source='get_full_name', read_only=True)
    
    class Meta:
        model = User
        fields = [
            'id', 'email', 'username', 'first_name', 'last_name', 'full_name',
            'phone_number', 'role', 'role_name', 'is_active', 'email_verified',
            'last_login', 'date_joined', 'mfa_enabled'
        ]
        read_only_fields = ['id', 'last_login', 'date_joined']


class UserCreateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=12)
    
    class Meta:
        model = User
        fields = [
            'email', 'username', 'first_name', 'last_name', 
            'password', 'role', 'is_staff'
        ]
    
    def create(self, validated_data):
        password = validated_data.pop('password')
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user


class UserProfileSerializer(serializers.ModelSerializer):
    role = RoleSerializer(read_only=True)
    unread_alerts = serializers.IntegerField(source='security_alerts.filter(is_read=False).count', read_only=True)
    
    class Meta:
        model = User
        fields = [
            'id', 'email', 'username', 'first_name', 'last_name',
            'phone_number', 'role', 'is_active', 'email_verified',
            'mfa_enabled', 'last_login_ip', 'last_password_change',
            'unread_alerts', 'date_joined'
        ]


class SecurityAlertSerializer(serializers.ModelSerializer):
    class Meta:
        model = SecurityAlert
        fields = ['id', 'alert_type', 'title', 'message', 'severity', 'is_read', 'created_at']


class UserSessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserSession
        fields = ['id', 'ip_address', 'location', 'device_type', 'created_at', 'last_activity', 'is_active']
