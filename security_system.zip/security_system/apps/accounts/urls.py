
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'users', views.UserViewSet, basename='user')
router.register(r'roles', views.RoleViewSet, basename='role')
router.register(r'alerts', views.SecurityAlertViewSet, basename='alert')

urlpatterns = [
    path('', include(router.urls)),
    path('login/', views.login_view, name='login'),
]
