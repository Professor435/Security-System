
from rest_framework import viewsets, status, generics
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.conf import settings
from django.utils import timezone

from .models import Role, SecurityAlert, UserSession
from .serializers import (
    UserSerializer, UserCreateSerializer, RoleSerializer, 
    SecurityAlertSerializer, UserProfileSerializer
)
from .authentication import MFAService

User = get_user_model()


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    permission_classes = [IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'create':
            return UserCreateSerializer
        return UserSerializer
    
    def get_queryset(self):
        if self.request.user.role and self.request.user.role.name == 'super_admin':
            return User.objects.all()
        return User.objects.filter(id=self.request.user.id)
    
    @action(detail=False, methods=['get'])
    def me(self, request):
        serializer = UserProfileSerializer(request.user)
        return Response(serializer.data)
    
    @action(detail=False, methods=['post'])
    def change_password(self, request):
        user = request.user
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')
        
        if not user.check_password(old_password):
            return Response({'error': 'Invalid old password'}, status=status.HTTP_400_BAD_REQUEST)
        
        user.set_password(new_password)
        user.last_password_change = timezone.now()
        user.save()
        
        # Invalidate all existing tokens
        RefreshToken.for_user(user)
        
        return Response({'message': 'Password changed successfully'})
    
    @action(detail=False, methods=['post'])
    def setup_mfa(self, request):
        user = request.user
        if user.mfa_enabled:
            return Response({'error': 'MFA already enabled'}, status=status.HTTP_400_BAD_REQUEST)
        
        secret = MFAService.generate_secret()
        uri = MFAService.get_totp_uri(secret, user)
        qr_code = MFAService.generate_qr_code(uri)
        
        # Store secret temporarily
        cache.set(f'mfa_setup_{user.id}', secret, timeout=300)
        
        return Response({
            'secret': secret,
            'qr_code': f'data:image/png;base64,{qr_code}',
            'message': 'Scan QR code with authenticator app and verify to enable MFA'
        })
    
    @action(detail=False, methods=['post'])
    def verify_mfa_setup(self, request):
        user = request.user
        token = request.data.get('token')
        secret = cache.get(f'mfa_setup_{user.id}')
        
        if not secret:
            return Response({'error': 'MFA setup expired'}, status=status.HTTP_400_BAD_REQUEST)
        
        if MFAService.verify_token(secret, token):
            user.mfa_enabled = True
            user.mfa_secret = secret
            user.save()
            cache.delete(f'mfa_setup_{user.id}')
            
            # Generate backup codes
            backup_codes = MFAService.generate_backup_codes()
            # Store hashed backup codes
            return Response({
                'message': 'MFA enabled successfully',
                'backup_codes': backup_codes  # Show only once
            })
        
        return Response({'error': 'Invalid token'}, status=status.HTTP_400_BAD_REQUEST)


class RoleViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Role.objects.filter(is_active=True)
    serializer_class = RoleSerializer
    permission_classes = [IsAuthenticated]


class SecurityAlertViewSet(viewsets.ModelViewSet):
    serializer_class = SecurityAlertSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return SecurityAlert.objects.filter(user=self.request.user)
    
    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        alert = self.get_object()
        alert.is_read = True
        alert.save()
        return Response({'status': 'marked as read'})


@api_view(['POST'])
@permission_classes([AllowAny])
def login_view(request):
    """Custom login with MFA support"""
    email = request.data.get('email')
    password = request.data.get('password')
    mfa_token = request.data.get('mfa_token')
    
    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
    
    if user.is_locked():
        return Response({
            'error': 'Account locked',
            'locked_until': user.locked_until
        }, status=status.HTTP_403_FORBIDDEN)
    
    if not user.check_password(password):
        user.record_failed_login()
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
    
    # Check MFA if enabled
    if user.mfa_enabled:
        if not mfa_token:
            return Response({
                'mfa_required': True,
                'message': 'Please provide MFA token'
            }, status=status.HTTP_401_UNAUTHORIZED)
        
        if not MFAService.verify_token(user.mfa_secret, mfa_token):
            return Response({'error': 'Invalid MFA token'}, status=status.HTTP_401_UNAUTHORIZED)
    
    # Successful login
    user.failed_login_attempts = 0
    user.last_login_ip = request.META.get('REMOTE_ADDR')
    user.last_login_user_agent = request.META.get('HTTP_USER_AGENT', '')
    user.save()
    
    # Create session
    refresh = RefreshToken.for_user(user)
    
    return Response({
        'refresh': str(refresh),
        'access': str(refresh.access_token),
        'user': UserSerializer(user).data
    })
