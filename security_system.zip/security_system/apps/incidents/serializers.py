
"""
Incident Serializers
"""

from rest_framework import serializers
from .models import Incident, IncidentUpdate, IncidentAttachment, Team, Playbook
from apps.accounts.serializers import UserBriefSerializer


class IncidentListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list views"""
    reporter_name = serializers.CharField(source='reporter.get_full_name', read_only=True)
    assigned_to_name = serializers.CharField(source='assigned_to.get_full_name', read_only=True)
    age_days = serializers.IntegerField(source='age.days', read_only=True)
    severity_color = serializers.CharField(source='get_severity_color', read_only=True)
    
    class Meta:
        model = Incident
        fields = [
            'id', 'incident_id', 'title', 'category', 'severity', 'status',
            'created_at', 'reporter_name', 'assigned_to_name', 'age_days',
            'severity_color', 'detection_time'
        ]


class IncidentUpdateSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(source='author.get_full_name', read_only=True)
    
    class Meta:
        model = IncidentUpdate
        fields = ['id', 'content', 'update_type', 'author', 'author_name', 'is_internal', 'created_at']
        read_only_fields = ['author']


class IncidentAttachmentSerializer(serializers.ModelSerializer):
    uploaded_by_name = serializers.CharField(source='uploaded_by.get_full_name', read_only=True)
    file_url = serializers.SerializerMethodField()
    
    class Meta:
        model = IncidentAttachment
        fields = ['id', 'filename', 'description', 'uploaded_by_name', 'uploaded_at', 'is_evidence', 'file_url']
    
    def get_file_url(self, obj):
        if obj.file:
            return obj.file.url
        return None


class IncidentSerializer(serializers.ModelSerializer):
    """Full incident serializer"""
    reporter = UserBriefSerializer(read_only=True)
    assigned_to = UserBriefSerializer(read_only=True)
    updates = IncidentUpdateSerializer(many=True, read_only=True)
    attachments = IncidentAttachmentSerializer(many=True, read_only=True)
    age_days = serializers.IntegerField(source='age.days', read_only=True)
    severity_color = serializers.CharField(source='get_severity_color', read_only=True)
    is_overdue = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = Incident
        fields = [
            'id', 'incident_id', 'title', 'description', 'category', 'severity', 'status',
            'detection_time', 'detection_method', 'source_ip', 'affected_assets',
            'impact_description', 'data_compromised', 'systems_affected',
            'financial_impact', 'reporter', 'assigned_to', 'team',
            'created_at', 'updated_at', 'resolved_at', 'closed_at',
            'root_cause', 'resolution_summary', 'lessons_learned', 'preventive_measures',
            'updates', 'attachments', 'age_days', 'severity_color', 'is_overdue',
            'tags', 'external_references', 'time_to_detect', 'time_to_resolve'
        ]
        read_only_fields = ['incident_id', 'created_at', 'updated_at', 'reporter']


class TeamSerializer(serializers.ModelSerializer):
    lead_name = serializers.CharField(source='lead.get_full_name', read_only=True)
    member_count = serializers.IntegerField(source='members.count', read_only=True)
    
    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'lead', 'lead_name', 'members', 'member_count', 'email', 'slack_channel', 'is_active']


class PlaybookSerializer(serializers.ModelSerializer):
    created_by_name = serializers.CharField(source='created_by.get_full_name', read_only=True)
    
    class Meta:
        model = Playbook
        fields = ['id', 'name', 'description', 'incident_category', 'severity_levels', 'steps', 'is_active', 'created_by_name', 'created_at']


class IncidentStatsSerializer(serializers.Serializer):
    total_open = serializers.IntegerField()
    critical_open = serializers.IntegerField()
    resolved_this_month = serializers.IntegerField()
    avg_resolution_time = serializers.DurationField()
    by_category = serializers.ListField()
    by_severity = serializers.ListField()


