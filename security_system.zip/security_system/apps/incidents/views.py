
"""
Incident Management API Views
"""

from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Count, Q, Avg, F
from django.utils import timezone
from datetime import timedelta

from .models import Incident, IncidentUpdate, IncidentAttachment, Team, Playbook
# from apps.accounts.models import User
from .serializers import (
    IncidentSerializer, IncidentListSerializer, IncidentUpdateSerializer,
    IncidentAttachmentSerializer, TeamSerializer, PlaybookSerializer,
    IncidentStatsSerializer
)
from apps.audit.models import AuditLog


class IncidentViewSet(viewsets.ModelViewSet):
    """Incident management endpoint"""
    queryset = Incident.objects.filter(is_deleted=False)
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'severity', 'category', 'assigned_to', 'team']
    search_fields = ['title', 'description', 'incident_id']
    ordering_fields = ['created_at', 'updated_at', 'severity', 'detection_time']
    
    def get_serializer_class(self):
        if self.action == 'list':
            return IncidentListSerializer
        return IncidentSerializer
    
    def perform_create(self, serializer):
        incident = serializer.save(reporter=self.request.user)
        # Log the creation
        AuditLog.objects.create(
            event_type=AuditLog.EventType.INCIDENT_CREATED,
            severity=AuditLog.Severity.HIGH if incident.severity in ['critical', 'high'] else AuditLog.Severity.MEDIUM,
            user=self.request.user,
            user_email=self.request.user.email,
            ip_address=self.request.META.get('REMOTE_ADDR'),
            resource_type='Incident',
            resource_id=str(incident.id),
            resource_name=incident.title,
            description=f"Incident {incident.incident_id} created",
            new_state=serializer.data
        )
        return incident
    
    def perform_update(self, serializer):
        old_instance = self.get_object()
        old_data = IncidentSerializer(old_instance).data
        incident = serializer.save()
        
        # Log the update
        AuditLog.objects.create(
            event_type=AuditLog.EventType.INCIDENT_UPDATED,
            severity=AuditLog.Severity.MEDIUM,
            user=self.request.user,
            user_email=self.request.user.email,
            ip_address=self.request.META.get('REMOTE_ADDR'),
            resource_type='Incident',
            resource_id=str(incident.id),
            resource_name=incident.title,
            description=f"Incident {incident.incident_id} updated",
            previous_state=old_data,
            new_state=serializer.data
        )
        return incident
    
    @action(detail=True, methods=['post'])
    def add_update(self, request, pk=None):
        """Add update to incident timeline"""
        incident = self.get_object()
        serializer = IncidentUpdateSerializer(data=request.data)
        if serializer.is_valid():
            update = serializer.save(incident=incident, author=request.user)
            return Response(IncidentUpdateSerializer(update).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def assign(self, request, pk=None):
        """Assign incident to user"""
        incident = self.get_object()
        user_id = request.data.get('user_id')
        if user_id:
            try:
                user = User.objects.get(id=user_id)
                incident.assigned_to = user
                incident.save()
                return Response({'status': 'assigned', 'user': user.email})
            except User.DoesNotExist:
                return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        return Response({'error': 'user_id required'}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def change_status(self, request, pk=None):
        """Change incident status"""
        incident = self.get_object()
        new_status = request.data.get('status')
        if new_status in dict(Incident.Status.choices):
            old_status = incident.status
            incident.status = new_status
            if new_status == Incident.Status.RESOLVED:
                incident.resolved_at = timezone.now()
            incident.save()
            
            # Create timeline update
            IncidentUpdate.objects.create(
                incident=incident,
                author=request.user,
                content=f"Status changed from {old_status} to {new_status}",
                update_type='status_change'
            )
            
            return Response({'status': 'updated', 'new_status': new_status})
        return Response({'error': 'Invalid status'}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def upload_attachment(self, request, pk=None):
        """Upload file attachment"""
        incident = self.get_object()
        file = request.FILES.get('file')
        if file:
            attachment = IncidentAttachment.objects.create(
                incident=incident,
                file=file,
                filename=file.name,
                uploaded_by=request.user
            )
            return Response(IncidentAttachmentSerializer(attachment).data, status=status.HTTP_201_CREATED)
        return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=False, methods=['get'])
    def dashboard_stats(self, request):
        """Get incident statistics for dashboard"""
        today = timezone.now()
        thirty_days_ago = today - timedelta(days=30)
        
        stats = {
            'total_open': Incident.objects.filter(status__in=['open', 'investigating', 'contained']).count(),
            'critical_open': Incident.objects.filter(severity='critical', status__in=['open', 'investigating']).count(),
            'high_open': Incident.objects.filter(severity='high', status__in=['open', 'investigating']).count(),
            'resolved_this_month': Incident.objects.filter(
                status='resolved', 
                resolved_at__gte=thirty_days_ago
            ).count(),
            'avg_resolution_time': Incident.objects.filter(
                time_to_resolve__isnull=False
            ).aggregate(avg=Avg('time_to_resolve'))['avg'],
            'by_category': Incident.objects.filter(created_at__gte=thirty_days_ago)
                .values('category').annotate(count=Count('id')),
            'by_severity': Incident.objects.filter(created_at__gte=thirty_days_ago)
                .values('severity').annotate(count=Count('id')),
            'trend': list(Incident.objects.filter(
                created_at__gte=thirty_days_ago
            ).extra({'date': "date(created_at)"}).values('date').annotate(count=Count('id')).order_by('date'))
        }
        return Response(stats)
    
    @action(detail=False, methods=['get'])
    def my_incidents(self, request):
        """Get incidents assigned to current user"""
        incidents = Incident.objects.filter(
            assigned_to=request.user,
            is_deleted=False
        ).exclude(status='closed')
        serializer = IncidentListSerializer(incidents, many=True)
        return Response(serializer.data)


class TeamViewSet(viewsets.ModelViewSet):
    """Team management"""
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]


class PlaybookViewSet(viewsets.ModelViewSet):
    """Incident response playbooks"""
    queryset = Playbook.objects.filter(is_active=True)
    serializer_class = PlaybookSerializer
    permission_classes = [IsAuthenticated]

