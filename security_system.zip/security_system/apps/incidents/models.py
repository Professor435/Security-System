"""
Security Incident Management Models
Tracks security incidents from detection to resolution
"""

import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone


class Incident(models.Model):
    """Security Incident Model"""
    
    class Severity(models.TextChoices):
        CRITICAL = 'critical', 'Critical'
        HIGH = 'high', 'High'
        MEDIUM = 'medium', 'Medium'
        LOW = 'low', 'Low'
        INFO = 'info', 'Informational'
    
    class Status(models.TextChoices):
        OPEN = 'open', 'Open'
        INVESTIGATING = 'investigating', 'Under Investigation'
        CONTAINED = 'contained', 'Contained'
        RESOLVED = 'resolved', 'Resolved'
        CLOSED = 'closed', 'Closed'
    
    class Category(models.TextChoices):
        MALWARE = 'malware', 'Malware'
        PHISHING = 'phishing', 'Phishing'
        DATA_BREACH = 'data_breach', 'Data Breach'
        DDOS = 'ddos', 'DDoS Attack'
        UNAUTHORIZED_ACCESS = 'unauthorized_access', 'Unauthorized Access'
        INSIDER_THREAT = 'insider_threat', 'Insider Threat'
        POLICY_VIOLATION = 'policy_violation', 'Policy Violation'
        PHYSICAL_SECURITY = 'physical_security', 'Physical Security'
        OTHER = 'other', 'Other'
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    incident_id = models.CharField(max_length=20, unique=True, editable=False)
    title = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=50, choices=Category.choices)
    severity = models.CharField(max_length=20, choices=Severity.choices, default=Severity.MEDIUM)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN)
    
    # Detection Details
    detection_time = models.DateTimeField(default=timezone.now)
    detection_method = models.CharField(max_length=255, blank=True)
    source_ip = models.GenericIPAddressField(null=True, blank=True)
    affected_assets = models.TextField(blank=True)
    
    # Impact Assessment
    impact_description = models.TextField(blank=True)
    data_compromised = models.BooleanField(default=False)
    systems_affected = models.PositiveIntegerField(default=0)
    estimated_downtime_hours = models.FloatField(default=0)
    financial_impact = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)
    
    # Assignment & Workflow
    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, 
                                 related_name='reported_incidents', null=True)
    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, 
                                    related_name='assigned_incidents', null=True, blank=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    
    # Resolution
    root_cause = models.TextField(blank=True)
    resolution_summary = models.TextField(blank=True)
    lessons_learned = models.TextField(blank=True)
    preventive_measures = models.TextField(blank=True)
    
    # Metadata
    tags = models.JSONField(default=list, blank=True)
    is_deleted = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-created_at']
    
    def save(self, *args, **kwargs):
        if not self.incident_id:
            self.incident_id = self.generate_incident_id()
        super().save(*args, **kwargs)
    
    def generate_incident_id(self):
        year = timezone.now().year
        count = Incident.objects.filter(created_at__year=year).count() + 1
        return f"INC-{year}-{count:05d}"
    
    def __str__(self):
        return f"{self.incident_id}: {self.title}"


class IncidentUpdate(models.Model):
    """Timeline updates for incidents"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    incident = models.ForeignKey(Incident, on_delete=models.CASCADE, related_name='updates')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']


class Team(models.Model):
    """Response teams"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    members = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='teams')
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return self.name


class IncidentAttachment(models.Model):
    """Incident attachments"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    incident = models.ForeignKey(Incident, on_delete=models.CASCADE, related_name='attachments')
    file = models.FileField(upload_to='incidents/%Y/%m/')
    filename = models.CharField(max_length=255)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.filename


class Playbook(models.Model):
    """Incident response playbooks"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    description = models.TextField()
    incident_category = models.CharField(max_length=50, choices=Incident.Category.choices)
    steps = models.JSONField(default=list)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['name']
    
    def __str__(self):
        return self.name