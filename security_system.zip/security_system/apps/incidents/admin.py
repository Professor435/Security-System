from django.contrib import admin
from .models import Incident, IncidentUpdate, Team

@admin.register(Incident)
class IncidentAdmin(admin.ModelAdmin):
    list_display = ['incident_id', 'title', 'severity', 'status', 'created_at']
    list_filter = ['severity', 'status', 'category']
    search_fields = ['incident_id', 'title', 'description']

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    filter_horizontal = ['members']