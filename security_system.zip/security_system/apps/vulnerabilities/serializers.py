
from rest_framework import serializers
from .models import Vulnerability, Asset, Scan


class AssetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Asset
        fields = '__all__'


class VulnerabilitySerializer(serializers.ModelSerializer):
    days_open = serializers.IntegerField(read_only=True)
    is_overdue = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = Vulnerability
        fields = '__all__'
        read_only_fields = ['vuln_id']


class ScanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Scan
        fields = '__all__'

        from rest_framework import serializers
from .models import Vulnerability


class VulnerabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Vulnerability
        fields = ['id', 'vuln_id', 'title', 'description', 'severity', 'status', 'created_at']
