from django.contrib import admin
from .models import Vulnerability, Asset

@admin.register(Vulnerability)
class VulnerabilityAdmin(admin.ModelAdmin):
    list_display = ['vuln_id', 'title', 'severity', 'status', 'created_at']
    list_filter = ['severity', 'status']

@admin.register(Asset)
class AssetAdmin(admin.ModelAdmin):
    list_display = ['name', 'asset_type', 'criticality', 'is_active']
    list_filter = ['asset_type', 'criticality']