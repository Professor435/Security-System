from django.apps import AppConfig

class VulnerabilitiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.vulnerabilities'
    label = 'vulnerabilities'
    verbose_name = 'Vulnerabilities'