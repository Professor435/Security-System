"""
Vulnerability Management Models
"""

import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone


class Vulnerability(models.Model):
    """Security Vulnerability"""
    
    class Severity(models.TextChoices):
        CRITICAL = 'critical', 'Critical'
        HIGH = 'high', 'High'
        MEDIUM = 'medium', 'Medium'
        LOW = 'low', 'Low'
        INFO = 'info', 'Informational'
    
    class Status(models.TextChoices):
        OPEN = 'open', 'Open'
        CONFIRMED = 'confirmed', 'Confirmed'
        IN_PROGRESS = 'in_progress', 'In Progress'
        RESOLVED = 'resolved', 'Resolved'
        FALSE_POSITIVE = 'false_positive', 'False Positive'
        RISK_ACCEPTED = 'risk_accepted', 'Risk Accepted'
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    vuln_id = models.CharField(max_length=50, unique=True, editable=False)
    title = models.CharField(max_length=255)
    description = models.TextField()
    cve_id = models.CharField(max_length=50, blank=True)
    severity = models.CharField(max_length=20, choices=Severity.choices)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN)
    
    # Assignment
    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, 
                                    null=True, blank=True, related_name='assigned_vulns')
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = 'Vulnerabilities'
    
    def save(self, *args, **kwargs):
        if not self.vuln_id:
            self.vuln_id = self.generate_vuln_id()
        super().save(*args, **kwargs)
    
    def generate_vuln_id(self):
        year = timezone.now().year
        count = Vulnerability.objects.filter(created_at__year=year).count() + 1
        return f"VULN-{year}-{count:05d}"
    
    
    def __str__(self):
        return f"{self.vuln_id}: {self.title}"
    

class Asset(models.Model):
    """IT Assets"""
    class AssetType(models.TextChoices):
        SERVER = 'server', 'Server'
        WORKSTATION = 'workstation', 'Workstation'
        NETWORK_DEVICE = 'network_device', 'Network Device'
        DATABASE = 'database', 'Database'
        APPLICATION = 'application', 'Application'
    
    class Criticality(models.TextChoices):
        CRITICAL = 'critical', 'Critical'
        HIGH = 'high', 'High'
        MEDIUM = 'medium', 'Medium'
        LOW = 'low', 'Low'
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    asset_type = models.CharField(max_length=50, choices=AssetType.choices)
    description = models.TextField(blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    criticality = models.CharField(max_length=20, choices=Criticality.choices, default=Criticality.MEDIUM)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['name']
    
    def __str__(self):
        return self.name


class Scan(models.Model):
    """Vulnerability Scan"""
    
    class ScanStatus(models.TextChoices):
        PENDING = 'pending', 'Pending'
        RUNNING = 'running', 'Running'
        COMPLETED = 'completed', 'Completed'
        FAILED = 'failed', 'Failed'
        CANCELLED = 'cancelled', 'Cancelled'
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    status = models.CharField(max_length=20, choices=ScanStatus.choices, default=ScanStatus.PENDING)
    scanner_tool = models.CharField(max_length=100, blank=True)
    total_vulnerabilities = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.name