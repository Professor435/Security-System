# config/urls.py
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from apps.core import views as core_views
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [ 
    path('admin/', admin.site.urls),

    # Authentication
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/login/'), name='logout'),

     # Main pages
    path('', core_views.dashboard, name='dashboard'),
    
    # Incidents
   path('incidents/', core_views.incidents, name='incident_list'),
path('incidents/create/', core_views.incident_create, name='incident_create'),
path('vulnerabilities/', core_views.vulnerabilities, name='vulnerability_list'),
path('vulnerabilities/create/', core_views.vulnerability_create, name='vulnerability_create'),
path('policies/', core_views.policies, name='policy_list'),
path('policies/create/', core_views.policy_create, name='policy_create'),
path('audit/', core_views.audit, name='audit'),


    # Dashboard
    path('', core_views.dashboard, name='dashboard'),
    path('', core_views.dashboard, name='dashboard'),
    path('incident/', core_views.incidents, name='incident'),
    path('vulnerabilities/', core_views.vulnerabilities, name='vulnerabilities'),
    path('policy/', core_views.policies, name='policy'),
    path('audit/', core_views.audit, name='audit'),


    # JWT Auth
    path('api/auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # App APIs
    path('api/accounts/', include('apps.accounts.urls')),
    path('api/incidents/', include('apps.incidents.urls')),
    path('api/vulnerabilities/', include('apps.vulnerabilities.urls')),
    path('api/policies/', include('apps.policies.urls')),
]
